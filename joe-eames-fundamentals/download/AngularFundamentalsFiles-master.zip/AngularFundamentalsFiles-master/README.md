Angular Fundamentals Course
========================

The course is up to date
